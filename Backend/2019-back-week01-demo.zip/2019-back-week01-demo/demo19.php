<html>
<head></head>
<body>
<?php
	$arrNamen = array("Jan","Piet","007"); 

	//een array overlopen kan je zo doen
	for($teller= 0; $teller < count($arrNamen); $teller++){
		echo $arrNamen[$teller];
	}

?>
</body>
</html>
