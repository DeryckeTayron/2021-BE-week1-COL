<html>
<head></head>
<body>
<?php
	$taal = "PHP";

	if ($taal == "PHP"){
		print("PHP werkt niet met indents (TABS) maar met {} om een blok aan te duiden");
	}else{
		print("in Python was dit anders");
	}
?>
</body>
</html>
