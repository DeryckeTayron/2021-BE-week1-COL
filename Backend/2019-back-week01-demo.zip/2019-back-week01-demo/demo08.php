<html>
<head></head>
<body>
<?php
	$deel1 = "een of meerdere variabelen gebruiken in een string";
	$deel2 = "binnen dubbele quotes";
	//een variabele binnen single quotes zal niet werken

	echo "$deel1 $deel2, noemen we string parsing";
?>
</body>
</html>
