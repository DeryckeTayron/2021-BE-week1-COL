<html>
<head></head>
<body>
<?php
	/* of met een slash en sterretje om te starten
	als je een blok in commentaar wil plaatsen.
	vergeet niet te eindigen met een sterretje en slash */
	echo "Elke lijn eindigt met een punt komma";
?>
</body>
</html>
