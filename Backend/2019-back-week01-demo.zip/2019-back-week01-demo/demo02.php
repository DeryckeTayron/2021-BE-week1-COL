<html>
<head></head>
<body>
<?php
	echo "Elke lijn eindigt met een punt komma";
?>
</body>
</html>
