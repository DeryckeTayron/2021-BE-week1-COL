<html>
<head></head>
<body>
<?php
	for($teller = 0; $teller <5; $teller++){
		// ook een for-lus gebruikt {} om zijn blok aan te duiden
		// de 3 expressies geven 
		// de start waarde -> $teller start bij de waarde 0
		// de eind waarde -> lus loopt zolang $teller kleiner dan 5 is
		// de stap waarde -> $teller verhoogt steeds met 1 ($teller+=1)
		echo $teller;
	}
?>
</body>
</html>
