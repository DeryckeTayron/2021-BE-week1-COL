<html>
<head></head>
<body>
Ik ben gewone html code en zal genegeerd worden door de PHP applicatie op de webserver
<?php
	echo "Alles dat tussen deze tags staat, wordt eerst verwerkt - en omgevormd naar HTML output - door de PHP applicatie op de webserver";
?>
Ik ben gewone html code en zal genegeerd worden door de PHP applicatie op de webserver
</body>
</html>
