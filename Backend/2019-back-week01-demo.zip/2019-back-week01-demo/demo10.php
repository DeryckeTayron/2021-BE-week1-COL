<html>
<head></head>
<body>
<?php
	$boodschap = "een variabele kan opnieuw verschillende gegevenstypes bevatten";
	$leeftijd = 55;

	print("$boodschap: $leeftijd");
?>
</body>
</html>
