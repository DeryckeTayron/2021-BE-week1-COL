<html>
<head></head>
<body>
<?php
	//een list uit Python is een array (met indexen) in PHP
	$arrNamen = array(); 
$arrNamen[0] = "Jan";
$arrNamen[1] = "Piet";
$arrNamen[2] = "007";

echo $arrNamen[2];
?>
</body>
</html>
