<html>
<head></head>
<body>
<?php
	//een dictionary uit Python is een array (met keys) in PHP

$arrKlas = array(); 
$arrKlas["Sandra"] = 3; 
$arrKlas["Mo"] = 5; 
$arrKlas["Karel"] = 7; 

echo $arrKlas["Mo"];
?>
</body>
</html>
