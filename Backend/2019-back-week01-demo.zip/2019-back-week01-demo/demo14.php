<html>
<head></head>
<body>
<?php
	echo "De echo’s kunnen ook perfect html tags bevatten";

	echo "<ul>";

	for($teller = 0; $teller <5; $teller++){
		echo "<li>$teller</li>";
	}

	echo "</ul>";

?>
</body>
</html>
