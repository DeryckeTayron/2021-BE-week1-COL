<html>
<head>
	<!-- Maar ik ben nog steeds html commentaar -->
</head>
<body>
<?php
	//commentaar schrijf je met dubbele slash binnen PHP
	echo "Elke lijn eindigt met een punt komma";
?>
</body>
</html>
