<html>
<head></head>
<body>
<?php
	$deel1 = "twee variabelen aan elkaar kleven (concatination)";
	$deel2 = "doe je via een . ";

	echo $deel1 . $deel2;
?>
</body>
</html>
