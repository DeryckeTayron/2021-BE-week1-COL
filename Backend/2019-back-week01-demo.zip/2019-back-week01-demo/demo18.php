<html>
<head></head>
<body>
<?php
	//een dictionary uit Python is een array (met keys) in PHP
	//en kan je ook korter schrijven

$arrKlas = array("Sandra" => 3, "Mo" => 5, "Karel" => 7); 

echo $arrKlas["Mo"];
?>
</body>
</html>
