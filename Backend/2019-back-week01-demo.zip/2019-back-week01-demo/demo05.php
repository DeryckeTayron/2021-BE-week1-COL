<html>
<head></head>
<body>
<?php
	$boodschap = "een variabele start met een dollarteken";
	echo $boodschap;
?>
</body>
</html>
