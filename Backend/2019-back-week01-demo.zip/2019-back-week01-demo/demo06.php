<html>
<head></head>
<body>
<?php
	$teTonenAandachtspunt = "we gebruiken geen underscore maar camel casing";
	echo $teTonenAandachtspunt;
?>
</body>
</html>
