<html>
<head></head>
<body>
<?php

	echo "gelijkheid kan je testen door == of ===";
	echo "== test enkel de waarde, dus ‘5’ == 5 is True";
	echo "=== test de waarde én gegevenstype ‘5’ === 5 is False ";

?>
</body>
</html>
