<html>
<head></head>
<body>
<?php
	//een list uit Python is een array (met indexen) in PHP
	//en kan je ook korter schrijven

	$arrNeerslag = array(100,151,2.5);
echo $arrNeerslag[2];
?>
</body>
</html>
