<html>
<head></head>
<body>
<?php
	$deel1 = "een alternatief voor echo";
	$deel2 = "is print, maar dan moet je wel (haakjes) plaatsen";

	print("$deel1 $deel2");
?>
</body>
</html>
